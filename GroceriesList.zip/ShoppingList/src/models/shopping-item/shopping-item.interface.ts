//Define the shopping Item
export interface ShoppingItem {
    $key?: string,
    itemName: string;
    itemNumber: number;
}


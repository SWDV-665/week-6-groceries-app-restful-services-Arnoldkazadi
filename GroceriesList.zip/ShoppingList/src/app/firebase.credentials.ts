export const FIREBASE_CREDENTIALS = {
    apiKey: "YOUR API KEY",
    authDomain: "shoppinglist-8fcb0.firebaseapp.com",
    databaseURL: "https://shoppinglist-8fcb0.firebaseio.com",
    projectId: "YOUR PROJECT ID",
    storageBucket: "shoppinglist-8fcb0.appspot.com",
    messagingSenderId: "YOUR messagingSenderId "
};
